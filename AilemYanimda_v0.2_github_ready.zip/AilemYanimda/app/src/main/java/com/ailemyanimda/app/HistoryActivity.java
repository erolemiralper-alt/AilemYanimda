package com.ailemyanimda.app;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import com.google.firebase.database.*;
import java.text.DateFormat;
import java.util.Date;

public class HistoryActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); LinearLayout r=Ui.root(this); r.addView(Ui.title(this,"Son konumlar")); TextView t=Ui.text(this,"Yükleniyor…",16); r.addView(t);
        ScrollView sv=new ScrollView(this); sv.addView(r); setContentView(sv);
        String secret=AppPrefs.secret(this);
        FirebaseProvider.db(this).getReference("families").child(secret).child("history").limitToLast(30).addListenerForSingleValueEvent(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){StringBuilder x=new StringBuilder(); for(DataSnapshot d:s.getChildren()){
                Double lat=d.child("lat").getValue(Double.class), lon=d.child("lon").getValue(Double.class); Long time=d.child("time").getValue(Long.class);
                if(lat!=null&&lon!=null&&time!=null)x.append(DateFormat.getDateTimeInstance().format(new Date(time))).append("\n").append(String.format(java.util.Locale.US,"%.5f, %.5f",lat,lon)).append("\n\n");
            } t.setText(x.length()==0?"Henüz konum kaydı yok.":x.toString());}
            @Override public void onCancelled(@NonNull DatabaseError e){t.setText(e.getMessage());}
        });
    }
}
