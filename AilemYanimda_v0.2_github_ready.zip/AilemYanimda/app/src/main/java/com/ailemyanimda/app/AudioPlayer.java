package com.ailemyanimda.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.util.Base64;
import androidx.annotation.NonNull;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AudioPlayer {
    private final Context context;
    private final DatabaseReference ref;
    private ValueEventListener listener;
    private AudioTrack track;
    private ExecutorService executor;
    private long lastSeq = Long.MIN_VALUE;
    private volatile boolean running = false;

    public AudioPlayer(Context context, DatabaseReference ref) {
        this.context = context.getApplicationContext();
        this.ref = ref;
    }

    public synchronized void start() {
        if (running) return;
        running = true;
        lastSeq = Long.MIN_VALUE;
        executor = Executors.newSingleThreadExecutor();
        createTrack();

        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                if (!running) return;
                Long seq = s.child("seq").getValue(Long.class);
                Long time = s.child("time").getValue(Long.class);
                String data = s.child("data").getValue(String.class);
                if (seq == null || data == null) return;
                if (time != null && Math.abs(System.currentTimeMillis() - time) > 2500L) {
                    lastSeq = Math.max(lastSeq, seq);
                    return;
                }
                if (seq <= lastSeq) return;
                lastSeq = seq;
                try {
                    byte[] ulaw = Base64.decode(data, Base64.DEFAULT);
                    short[] pcm = G711.decode(ulaw);
                    ExecutorService x = executor;
                    if (x != null) x.execute(() -> play(pcm));
                } catch (Exception ignored) {}
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        ref.addValueEventListener(listener);
    }

    private void createTrack() {
        int min = AudioTrack.getMinBufferSize(AudioSender.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) min = 4096;
        int buffer = Math.max(min, 4096);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
        AudioFormat format = new AudioFormat.Builder()
                .setSampleRate(AudioSender.SAMPLE_RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build();
        try {
            track = new AudioTrack(attrs, format, buffer, AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE);
            track.play();
        } catch (Exception ignored) {
            track = null;
        }
    }

    private void play(short[] pcm) {
        AudioTrack t = track;
        if (!running || t == null) return;
        try { t.write(pcm, 0, pcm.length, AudioTrack.WRITE_BLOCKING); } catch (Exception ignored) {}
    }

    public synchronized void stop() {
        running = false;
        if (listener != null) {
            ref.removeEventListener(listener);
            listener = null;
        }
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
        if (track != null) {
            try { track.pause(); } catch (Exception ignored) {}
            try { track.flush(); } catch (Exception ignored) {}
            try { track.release(); } catch (Exception ignored) {}
            track = null;
        }
    }

    public boolean isRunning() { return running; }
}
