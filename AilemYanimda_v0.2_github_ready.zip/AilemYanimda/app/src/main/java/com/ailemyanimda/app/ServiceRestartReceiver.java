package com.ailemyanimda.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.content.ContextCompat;

/**
 * Kucuk bir watchdog: eslestirilmis anne telefonunda servis beklenmedik sekilde
 * kapanirsa veya cihaz yeni acildiysa gorunur foreground servisini yeniden baslatir.
 */
public class ServiceRestartReceiver extends BroadcastReceiver {
    private static final int REQ_SHORT = 1907;
    private static final int REQ_WATCHDOG = 1908;
    private static final long WATCHDOG_MS = 5 * 60 * 1000L;

    @Override public void onReceive(Context context, Intent intent) {
        if (!isTracked(context)) return;
        startTracking(context);
        // Tek seferlik alarm kendini yeniden kurar. Bu, Android 10 gibi eski cihazlarda
        // servis beklenmedik sekilde oldurulurse makul surede yeniden deneme saglar.
        schedule(context, WATCHDOG_MS);
    }

    public static boolean isTracked(Context c) {
        return "tracked".equals(AppPrefs.role(c)) && !AppPrefs.secret(c).isEmpty();
    }

    public static void startTracking(Context context) {
        if (!isTracked(context)) return;
        Intent service = new Intent(context, TrackingService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(context, service);
            else context.startService(service);
        } catch (Exception ignored) {
            // Uretici kisitlamasi varsa bir sonraki watchdog tekrar dener.
        }
    }

    public static void schedule(Context context, long delayMs) {
        if (!isTracked(context)) return;
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(context, ServiceRestartReceiver.class);
            int requestCode = delayMs <= 60_000L ? REQ_SHORT : REQ_WATCHDOG;
            PendingIntent pi = PendingIntent.getBroadcast(
                    context, requestCode, i,
                    PendingIntent.FLAG_UPDATE_CURRENT |
                            (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            long at = System.currentTimeMillis() + Math.max(5000L, delayMs);
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (Exception ignored) {}
    }
}
