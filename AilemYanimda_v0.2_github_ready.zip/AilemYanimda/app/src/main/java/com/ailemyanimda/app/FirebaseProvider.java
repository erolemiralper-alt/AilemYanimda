package com.ailemyanimda.app;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public final class FirebaseProvider {
    private static final String APP_NAME = "AilemYanimda";
    private static FirebaseApp app;

    public static synchronized FirebaseApp app(Context c) {
        if (app != null) return app;
        for (FirebaseApp a : FirebaseApp.getApps(c)) {
            if (APP_NAME.equals(a.getName())) { app = a; return app; }
        }
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(AppPrefs.get(c,"fb_api_key"))
                .setApplicationId(AppPrefs.get(c,"fb_app_id"))
                .setProjectId(AppPrefs.get(c,"fb_project_id"))
                .setDatabaseUrl(AppPrefs.get(c,"fb_db_url"))
                .build();
        app = FirebaseApp.initializeApp(c, options, APP_NAME);
        return app;
    }

    public static FirebaseAuth auth(Context c) { return FirebaseAuth.getInstance(app(c)); }
    public static FirebaseDatabase db(Context c) { return FirebaseDatabase.getInstance(app(c)); }
}
