package com.ailemyanimda.app;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public final class FirebaseProvider {
    private static final String APP_NAME = "AilemYanimda";

    // Firebase Android istemci yapılandırması uygulamanın içine gömülüdür.
    // Bunlar parola değildir; erişim güvenliği Firebase Authentication + Database Rules ile sağlanır.
    private static final String API_KEY = "AIzaSyAYQQDim7qSOduhFGwAdgAKEqRwa-BEtg0";
    private static final String APP_ID = "1:43851887564:android:4d871ee5028a806cb26369";
    private static final String PROJECT_ID = "ailemyanimda-4ace5";
    private static final String DATABASE_URL = "https://ailemyanimda-4ace5-default-rtdb.europe-west1.firebasedatabase.app";

    private static FirebaseApp app;

    public static synchronized FirebaseApp app(Context c) {
        if (app != null) return app;
        for (FirebaseApp a : FirebaseApp.getApps(c)) {
            if (APP_NAME.equals(a.getName())) { app = a; return app; }
        }
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(API_KEY)
                .setApplicationId(APP_ID)
                .setProjectId(PROJECT_ID)
                .setDatabaseUrl(DATABASE_URL)
                .build();
        app = FirebaseApp.initializeApp(c, options, APP_NAME);
        return app;
    }

    public static FirebaseAuth auth(Context c) { return FirebaseAuth.getInstance(app(c)); }
    public static FirebaseDatabase db(Context c) { return FirebaseDatabase.getInstance(app(c)); }
}
