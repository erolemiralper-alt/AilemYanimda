package com.ailemyanimda.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.database.DatabaseReference;
import java.util.HashMap;
import java.util.Map;

public class TrackedActivity extends AppCompatActivity {
    private static final int REQ=42;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); LinearLayout r=Ui.root(this); r.addView(Ui.title(this,"Ailem Yanımda"));
        r.addView(Ui.text(this,"✓ Telefon eşleştirildi\nKonum ve pil bilgisi otomatik gönderilir. Kamera kullanılırken telefonda bildirim görünür.",18));
        android.widget.Button permission=Ui.button(this,"İzinleri ver / kontrol et",0xff1769d2);
        android.widget.Button sos=Ui.button(this,"SOS — Yardım iste",0xffd93a36);
        android.widget.Button start=Ui.button(this,"Takibi başlat",0xff2ead5b);
        permission.setOnClickListener(v->askPermissions()); start.setOnClickListener(v->startTracking()); sos.setOnClickListener(v->sendSos());
        r.addView(permission); r.addView(start); r.addView(Ui.spacer(this,15)); r.addView(sos);
        r.addView(Ui.text(this,"Bu uygulama gizlenmez. Konum takibi ve kamera paylaşımı telefonun bildirim alanında görünür.",14));
        setContentView(r); askPermissions();
    }
    private void askPermissions(){
        java.util.ArrayList<String> p=new java.util.ArrayList<>();
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.CAMERA);
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS);
        if(p.isEmpty()) startTracking(); else ActivityCompat.requestPermissions(this,p.toArray(new String[0]),REQ);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==REQ)startTracking();}
    private void startTracking(){
        Intent i=new Intent(this,TrackingService.class);
        if(Build.VERSION.SDK_INT>=26) ContextCompat.startForegroundService(this,i); else startService(i);
        Toast.makeText(this,"Takip etkin.",Toast.LENGTH_SHORT).show();
    }
    private void sendSos(){
        String s=AppPrefs.secret(this); if(s.isEmpty())return; long now=System.currentTimeMillis();
        DatabaseReference base=FirebaseProvider.db(this).getReference("families").child(s);
        Map<String,Object> m=new HashMap<>(); m.put("time",now); m.put("message","SOS");
        base.child("sos").child(String.valueOf(now)).setValue(m); base.child("latest/sosAt").setValue(now);
        Toast.makeText(this,"SOS bildirimi gönderildi.",Toast.LENGTH_LONG).show();
    }
}
