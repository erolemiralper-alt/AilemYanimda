package com.ailemyanimda.app;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class CaregiverActivity extends AppCompatActivity {
    private DatabaseReference base;
    private TextView status, location, sos;
    private ImageView camera;
    private WebView map;
    private boolean cameraOn=false;
    private String lens="back";
    private ValueEventListener statusListener, locationListener, sosListener, frameListener;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout r=Ui.root(this); r.addView(Ui.title(this,"Annem — Kontrol"));
        status=Ui.text(this,"Bağlanıyor…",17); location=Ui.text(this,"Konum bekleniyor…",16); sos=Ui.text(this,"SOS: yok",16);
        r.addView(status); r.addView(location); r.addView(sos);
        map=new WebView(this); map.setLayoutParams(new LinearLayout.LayoutParams(-1,Ui.dp(this,250))); WebSettings ws=map.getSettings(); ws.setJavaScriptEnabled(true); r.addView(map);
        android.widget.Button cam=Ui.button(this,"Kamerayı aç",0xff2ead5b);
        android.widget.Button flip=Ui.button(this,"Kamera: arka",0xff17365d);
        android.widget.Button history=Ui.button(this,"Konum geçmişi",0xff1769d2);
        camera=new ImageView(this); camera.setAdjustViewBounds(true); camera.setMinimumHeight(Ui.dp(this,220)); camera.setBackgroundColor(0xff111111);
        r.addView(cam); r.addView(flip); r.addView(camera); r.addView(history);
        TextView note=Ui.text(this,"Kamera açıkken annenizin telefonunda görünür bir bildirim bulunur. Bu sürüm eski telefonları yormamak için yaklaşık 5 saniyede bir düşük çözünürlüklü görüntü yeniler.",14); note.setGravity(Gravity.CENTER); r.addView(note);
        ScrollView sv=new ScrollView(this); sv.addView(r); setContentView(sv);

        cam.setOnClickListener(v->{cameraOn=!cameraOn; if(base!=null)base.child("commands/cameraEnabled").setValue(cameraOn); cam.setText(cameraOn?"Kamerayı kapat":"Kamerayı aç");});
        flip.setOnClickListener(v->{ lens = "back".equals(lens) ? "front" : "back"; if(base!=null)base.child("commands/lens").setValue(lens); flip.setText("Kamera: "+("back".equals(lens)?"arka":"ön")); });
        history.setOnClickListener(v->startActivity(new Intent(this,HistoryActivity.class)));
        connect();
    }

    private void connect(){
        FirebaseAuth a=FirebaseProvider.auth(this);
        Runnable go=()->{
            String secret=AppPrefs.secret(this); if(secret.isEmpty()){Toast.makeText(this,"Eşleştirme bulunamadı.",Toast.LENGTH_LONG).show(); return;}
            base=FirebaseProvider.db(this).getReference("families").child(secret);
            listen();
        };
        if(a.getCurrentUser()!=null)go.run(); else a.signInAnonymously().addOnSuccessListener(x->go.run()).addOnFailureListener(e->Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());
    }

    private void listen(){
        statusListener=new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){
                Boolean online=s.child("online").getValue(Boolean.class); Long seen=s.child("lastSeen").getValue(Long.class); Long battery=s.child("battery").getValue(Long.class);
                String st=(Boolean.TRUE.equals(online)?"Çevrimiçi":"Çevrimdışı")+"   Pil: "+(battery==null?"?":battery+"%");
                if(seen!=null)st+="\nSon bağlantı: "+DateFormat.getDateTimeInstance().format(new Date(seen)); status.setText(st);
            }
            @Override public void onCancelled(@NonNull DatabaseError e){status.setText(e.getMessage());}
        };
        locationListener=new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){
                Double lat=s.child("lat").getValue(Double.class), lon=s.child("lon").getValue(Double.class); Long time=s.child("time").getValue(Long.class);
                if(lat!=null&&lon!=null){ location.setText(String.format(Locale.US,"Konum: %.5f, %.5f%s",lat,lon,time==null?"":"\n"+DateFormat.getDateTimeInstance().format(new Date(time)))); showMap(lat,lon); }
            }
            @Override public void onCancelled(@NonNull DatabaseError e){location.setText(e.getMessage());}
        };
        sosListener=new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){Long sosAt=s.child("sosAt").getValue(Long.class); sos.setText(sosAt==null?"SOS: yok":"SOS: "+DateFormat.getDateTimeInstance().format(new Date(sosAt)));}
            @Override public void onCancelled(@NonNull DatabaseError e){}
        };
        frameListener=new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){String jpeg=s.child("jpeg").getValue(String.class); if(jpeg==null)return; try{byte[] b=Base64.decode(jpeg,Base64.DEFAULT); camera.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.length));}catch(Exception ignored){}}
            @Override public void onCancelled(@NonNull DatabaseError e){}
        };
        base.child("status").addValueEventListener(statusListener);
        base.child("location").addValueEventListener(locationListener);
        base.child("latest").addValueEventListener(sosListener);
        base.child("camera/frame").addValueEventListener(frameListener);
    }

    private void showMap(double lat,double lon){
        double d=.006; String u=String.format(Locale.US,"https://www.openstreetmap.org/export/embed.html?bbox=%f%%2C%f%%2C%f%%2C%f&layer=mapnik&marker=%f%%2C%f",lon-d,lat-d,lon+d,lat+d,lat,lon); map.loadUrl(u);
    }

    @Override protected void onStop(){ super.onStop(); if(base!=null && cameraOn){cameraOn=false;base.child("commands/cameraEnabled").setValue(false);} }
    @Override protected void onDestroy(){
        super.onDestroy();
        if(base!=null){
            if(statusListener!=null)base.child("status").removeEventListener(statusListener);
            if(locationListener!=null)base.child("location").removeEventListener(locationListener);
            if(sosListener!=null)base.child("latest").removeEventListener(sosListener);
            if(frameListener!=null)base.child("camera/frame").removeEventListener(frameListener);
        }
        map.destroy();
    }
}
