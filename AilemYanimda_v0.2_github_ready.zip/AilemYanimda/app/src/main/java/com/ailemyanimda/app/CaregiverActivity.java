package com.ailemyanimda.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class CaregiverActivity extends AppCompatActivity {
    private static final int REQ_AUDIO = 77;

    private DatabaseReference base;
    private TextView status, location, sos, voiceStatus;
    private ZoomImageView camera;
    private WebView map;
    private Button camButton, flipButton, cameraSizeButton, listenButton, talkButton;
    private boolean cameraOn = false;
    private boolean cameraLarge = false;
    private boolean listening = false;
    private boolean talking = false;
    private boolean restoreListenAfterTalk = false;
    private String lens = "back";
    private long lastMapTouchAt = 0L;
    private ValueEventListener statusListener, locationListener, sosListener, frameListener;
    private AudioPlayer momAudio;
    private AudioSender talkAudio;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout r = Ui.root(this);
        r.addView(Ui.title(this, "Annem — Kontrol"));
        status = Ui.text(this, "Bağlanıyor…", 17);
        location = Ui.text(this, "Konum bekleniyor…", 16);
        sos = Ui.text(this, "SOS: yok", 16);
        voiceStatus = Ui.text(this, "Ses: kapalı", 15);
        r.addView(status);
        r.addView(location);
        r.addView(sos);

        map = new WebView(this);
        map.setLayoutParams(new LinearLayout.LayoutParams(-1, Ui.dp(this, 300)));
        WebSettings ws = map.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setSupportZoom(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        map.setOverScrollMode(View.OVER_SCROLL_NEVER);
        map.setFocusable(true);
        map.setFocusableInTouchMode(true);
        map.setOnTouchListener((v, event) -> {
            int a = event.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_POINTER_DOWN || a == MotionEvent.ACTION_POINTER_UP) {
                lastMapTouchAt = System.currentTimeMillis();
                v.getParent().requestDisallowInterceptTouchEvent(true);
                v.requestFocus();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                lastMapTouchAt = System.currentTimeMillis();
                v.getParent().requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        r.addView(map);

        camButton = Ui.button(this, "Kamerayı aç", 0xff2ead5b);
        flipButton = Ui.button(this, "Kamera: arka", 0xff17365d);
        Button history = Ui.button(this, "Konum geçmişi", 0xff1769d2);
        camera = new ZoomImageView(this);
        camera.setLayoutParams(new LinearLayout.LayoutParams(-1, Ui.dp(this, 360)));
        camera.setBackgroundColor(0xff111111);
        cameraSizeButton = Ui.button(this, "Kamera alanını büyüt", 0xff4a4a4a);
        TextView cameraHelp = Ui.text(this, "Kamera: iki parmakla yakınlaştır • sürükle • çift dokununca sıfırla", 14);
        cameraHelp.setGravity(Gravity.CENTER);
        r.addView(camButton);
        r.addView(flipButton);
        r.addView(camera);
        r.addView(cameraSizeButton);
        r.addView(cameraHelp);

        r.addView(Ui.spacer(this, 8));
        r.addView(Ui.title(this, "Sesli iletişim"));
        listenButton = Ui.button(this, "Annemin sesini dinle", 0xff1769d2);
        talkButton = Ui.button(this, "Basılı tut ve konuş", 0xff8a4b08);
        r.addView(listenButton);
        r.addView(talkButton);
        r.addView(voiceStatus);
        r.addView(history);

        TextView note = Ui.text(this,
                "Kamera veya mikrofon paylaşımı açıkken annenizin telefonunda görünür bildirim bulunur. " +
                "Ses, düşük veri kullanımı için telefon görüşmesi kalitesinde aktarılır. Konuş düğmesi basılı tutulduğunda dinleme kısa süreli durur; böylece yankı azalır.", 14);
        note.setGravity(Gravity.CENTER);
        r.addView(note);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(r);
        setContentView(sv);

        camButton.setOnClickListener(v -> {
            cameraOn = !cameraOn;
            if (base != null) base.child("commands/cameraEnabled").setValue(cameraOn);
            camButton.setText(cameraOn ? "Kamerayı kapat" : "Kamerayı aç");
        });
        cameraSizeButton.setOnClickListener(v -> {
            cameraLarge = !cameraLarge;
            int h = Ui.dp(this, cameraLarge ? 540 : 360);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) camera.getLayoutParams();
            lp.height = h;
            camera.setLayoutParams(lp);
            camera.post(camera::resetZoom);
            cameraSizeButton.setText(cameraLarge ? "Kamera alanını küçült" : "Kamera alanını büyüt");
        });
        flipButton.setOnClickListener(v -> {
            lens = "back".equals(lens) ? "front" : "back";
            if (base != null) base.child("commands/lens").setValue(lens);
            flipButton.setText("Kamera: " + ("back".equals(lens) ? "arka" : "ön"));
        });
        listenButton.setOnClickListener(v -> toggleListening());
        talkButton.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                beginTalking();
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                endTalking();
                v.performClick();
                return true;
            }
            return true;
        });
        history.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        connect();
    }

    private void toggleListening() {
        if (base == null) return;
        listening = !listening;
        if (listening) {
            base.child("commands/audioEnabled").setValue(true);
            if (momAudio != null && !talking) momAudio.start();
            listenButton.setText("Dinlemeyi kapat");
            voiceStatus.setText("Ses: annenizin mikrofonu dinleniyor");
        } else {
            base.child("commands/audioEnabled").setValue(false);
            if (momAudio != null) momAudio.stop();
            listenButton.setText("Annemin sesini dinle");
            voiceStatus.setText("Ses: kapalı");
        }
    }

    private void beginTalking() {
        if (talking || base == null) return;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            Toast.makeText(this, "Konuşmak için mikrofon izni verin; sonra düğmeye tekrar basılı tutun.", Toast.LENGTH_LONG).show();
            return;
        }

        talking = true;
        restoreListenAfterTalk = listening;
        if (restoreListenAfterTalk) {
            base.child("commands/audioEnabled").setValue(false);
            if (momAudio != null) momAudio.stop();
        }
        talkButton.setText("Konuşuyorsun… bırakınca durur");
        voiceStatus.setText("Ses: annenizin telefonuna konuşuyorsunuz");
        base.child("commands/caregiverTalking").setValue(true).addOnCompleteListener(t -> {
            if (talking && talkAudio != null) {
                boolean ok = talkAudio.start();
                if (!ok) runOnUiThread(() -> Toast.makeText(this, "Mikrofon başlatılamadı.", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void endTalking() {
        if (!talking) return;
        talking = false;
        if (talkAudio != null) talkAudio.stop();
        if (base != null) base.child("commands/caregiverTalking").setValue(false);
        talkButton.setText("Basılı tut ve konuş");

        if (restoreListenAfterTalk && listening && base != null) {
            base.child("commands/audioEnabled").setValue(true);
            if (momAudio != null) momAudio.start();
            voiceStatus.setText("Ses: annenizin mikrofonu dinleniyor");
        } else {
            voiceStatus.setText(listening ? "Ses: annenizin mikrofonu dinleniyor" : "Ses: kapalı");
        }
        restoreListenAfterTalk = false;
    }

    private void connect() {
        FirebaseAuth a = FirebaseProvider.auth(this);
        Runnable go = () -> {
            String secret = AppPrefs.secret(this);
            if (secret.isEmpty()) {
                Toast.makeText(this, "Eşleştirme bulunamadı.", Toast.LENGTH_LONG).show();
                return;
            }
            base = FirebaseProvider.db(this).getReference("families").child(secret);
            momAudio = new AudioPlayer(this, base.child("audio/fromTracked"));
            talkAudio = new AudioSender(this, base.child("audio/fromCaregiver"));
            listen();
        };
        if (a.getCurrentUser() != null) go.run();
        else a.signInAnonymously().addOnSuccessListener(x -> go.run()).addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void listen() {
        statusListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                Boolean online = s.child("online").getValue(Boolean.class);
                Long seen = s.child("lastSeen").getValue(Long.class);
                Long battery = s.child("battery").getValue(Long.class);
                Boolean audioMissing = s.child("audioPermissionMissing").getValue(Boolean.class);
                String st = (Boolean.TRUE.equals(online) ? "Çevrimiçi" : "Çevrimdışı") + "   Pil: " + (battery == null ? "?" : battery + "%");
                if (seen != null) st += "\nSon bağlantı: " + DateFormat.getDateTimeInstance().format(new Date(seen));
                if (Boolean.TRUE.equals(audioMissing)) st += "\n⚠ Annenizin telefonunda mikrofon izni eksik.";
                status.setText(st);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { status.setText(e.getMessage()); }
        };
        locationListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                Double lat = s.child("lat").getValue(Double.class), lon = s.child("lon").getValue(Double.class);
                Long time = s.child("time").getValue(Long.class);
                if (lat != null && lon != null) {
                    location.setText(String.format(Locale.US, "Konum: %.5f, %.5f%s", lat, lon,
                            time == null ? "" : "\n" + DateFormat.getDateTimeInstance().format(new Date(time))));
                    // Kullanıcı haritayı yakınlaştırırken dış ScrollView artık hareket etmez. Ayrıca
                    // parmakla etkileşimden hemen sonra haritayı yeniden yükleyip zoom'u sıfırlamıyoruz.
                    if (System.currentTimeMillis() - lastMapTouchAt > 15000L) showMap(lat, lon);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { location.setText(e.getMessage()); }
        };
        sosListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                Long sosAt = s.child("sosAt").getValue(Long.class);
                sos.setText(sosAt == null ? "SOS: yok" : "SOS: " + DateFormat.getDateTimeInstance().format(new Date(sosAt)));
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        frameListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                String jpeg = s.child("jpeg").getValue(String.class);
                if (jpeg == null) return;
                try {
                    byte[] b = Base64.decode(jpeg, Base64.DEFAULT);
                    camera.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
                } catch (Exception ignored) {}
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        base.child("status").addValueEventListener(statusListener);
        base.child("location").addValueEventListener(locationListener);
        base.child("latest").addValueEventListener(sosListener);
        base.child("camera/frame").addValueEventListener(frameListener);
    }

    private void showMap(double lat, double lon) {
        double d = .006;
        String u = String.format(Locale.US,
                "https://www.openstreetmap.org/export/embed.html?bbox=%f%%2C%f%%2C%f%%2C%f&layer=mapnik&marker=%f%%2C%f",
                lon - d, lat - d, lon + d, lat + d, lat, lon);
        map.loadUrl(u);
    }

    @Override protected void onStop() {
        super.onStop();
        if (base != null) {
            if (cameraOn) {
                cameraOn = false;
                base.child("commands/cameraEnabled").setValue(false);
                if (camButton != null) camButton.setText("Kamerayı aç");
            }
            if (listening) {
                listening = false;
                base.child("commands/audioEnabled").setValue(false);
                if (listenButton != null) listenButton.setText("Annemin sesini dinle");
            }
        }
        endTalking();
        if (momAudio != null) momAudio.stop();
        if (talkAudio != null) talkAudio.stop();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (momAudio != null) momAudio.stop();
        if (talkAudio != null) talkAudio.stop();
        if (base != null) {
            if (statusListener != null) base.child("status").removeEventListener(statusListener);
            if (locationListener != null) base.child("location").removeEventListener(locationListener);
            if (sosListener != null) base.child("latest").removeEventListener(sosListener);
            if (frameListener != null) base.child("camera/frame").removeEventListener(frameListener);
        }
        if (map != null) map.destroy();
    }
}
