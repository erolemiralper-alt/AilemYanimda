package com.ailemyanimda.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.*;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.util.HashMap;
import java.util.Map;

public class TrackingService extends Service implements LocationListener {
    private static final String CH = "ailem_tracking";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private DatabaseReference base;
    private LocationManager lm;
    private CameraStreamer camera;
    private AudioSender micSender;
    private AudioPlayer caregiverAudio;
    private String lens = "back";
    private boolean cameraOn = false;
    private boolean micOn = false;
    private boolean caregiverTalking = false;
    private ValueEventListener cameraListener, lensListener, audioListener, caregiverTalkingListener;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(1001, notification("Konum takibi açık"));
        authenticate();
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        // START_STICKY: sistem sureci oldururse servisi tekrar olusturmayi dener.
        if (!ServiceRestartReceiver.isTracked(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        ServiceRestartReceiver.schedule(this, 5 * 60 * 1000L);
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Son uygulamalar ekranindan uygulama kaydirilsa bile takip servisini geri getirmeyi dene.
        ServiceRestartReceiver.schedule(this, 5_000L);
        super.onTaskRemoved(rootIntent);
    }
    @Override public android.os.IBinder onBind(Intent i) { return null; }

    private void authenticate() {
        FirebaseAuth a = FirebaseProvider.auth(this);
        Runnable go = this::startLogic;
        if (a.getCurrentUser() != null) go.run();
        else a.signInAnonymously().addOnSuccessListener(x -> go.run());
    }

    private void startLogic() {
        String secret = AppPrefs.secret(this);
        if (secret.isEmpty()) { stopSelf(); return; }
        base = FirebaseProvider.db(this).getReference("families").child(secret);
        DatabaseReference online = base.child("status/online");
        online.onDisconnect().setValue(false);
        online.setValue(true);

        camera = new CameraStreamer(this, base.child("camera/frame"));
        micSender = new AudioSender(this, base.child("audio/fromTracked"));
        caregiverAudio = new AudioPlayer(this, base.child("audio/fromCaregiver"));

        cameraListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                Boolean on = s.getValue(Boolean.class);
                cameraOn = Boolean.TRUE.equals(on);
                if (cameraOn) camera.start(lens); else camera.stop();
                updateForegroundState();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        lensListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                String x = s.getValue(String.class);
                if (x != null) {
                    lens = x;
                    camera.stop();
                    if (cameraOn) camera.start(lens);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        audioListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                Boolean requested = s.getValue(Boolean.class);
                boolean hasPermission = ContextCompat.checkSelfPermission(TrackingService.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                micOn = Boolean.TRUE.equals(requested) && hasPermission;
                if (micOn) micSender.start(); else micSender.stop();
                if (Boolean.TRUE.equals(requested) && !hasPermission) base.child("status/audioPermissionMissing").setValue(true);
                else base.child("status/audioPermissionMissing").setValue(false);
                updateForegroundState();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        caregiverTalkingListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                caregiverTalking = Boolean.TRUE.equals(s.getValue(Boolean.class));
                if (caregiverTalking) caregiverAudio.start(); else caregiverAudio.stop();
                updateForegroundState();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        base.child("commands/cameraEnabled").addValueEventListener(cameraListener);
        base.child("commands/lens").addValueEventListener(lensListener);
        base.child("commands/audioEnabled").addValueEventListener(audioListener);
        base.child("commands/caregiverTalking").addValueEventListener(caregiverTalkingListener);

        beginLocation();
        handler.post(heartbeat);
    }

    private void beginLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 10, this); } catch (Exception ignored) {}
        try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60000, 10, this); } catch (Exception ignored) {}
        try {
            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l != null) onLocationChanged(l);
        } catch (Exception ignored) {}
    }

    @Override public void onLocationChanged(@NonNull Location l) {
        if (base == null) return;
        long now = System.currentTimeMillis();
        Map<String, Object> m = new HashMap<>();
        m.put("lat", l.getLatitude());
        m.put("lon", l.getLongitude());
        m.put("accuracy", (double) l.getAccuracy());
        m.put("time", now);
        base.child("location").setValue(m);
        base.child("history").child(String.valueOf(now)).setValue(m);
    }

    @Override public void onProviderEnabled(@NonNull String p) {}
    @Override public void onProviderDisabled(@NonNull String p) {}

    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (base != null) {
                IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                Intent b = registerReceiver(null, f);
                int pct = -1;
                if (b != null) {
                    int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    if (level >= 0 && scale > 0) pct = Math.round(level * 100f / scale);
                }
                Map<String, Object> s = new HashMap<>();
                s.put("online", true);
                s.put("lastSeen", System.currentTimeMillis());
                s.put("battery", pct);
                s.put("model", Build.MODEL);
                base.child("status").updateChildren(s);
            }
            handler.postDelayed(this, 30000);
        }
    };

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Ailem Yanımda", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Konum, kamera ve mikrofon paylaşım durumu");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification(String text) {
        Intent i = new Intent(this, TrackedActivity.class);
        PendingIntent p = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        return new NotificationCompat.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("Ailem Yanımda")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(p)
                .build();
    }

    private void updateForegroundState() {
        String text;
        if (cameraOn && micOn) text = "Konum + kamera + mikrofon paylaşımı açık";
        else if (cameraOn) text = "Konum + kamera paylaşımı açık";
        else if (micOn) text = "Konum + mikrofon paylaşımı açık";
        else text = "Konum takibi açık";
        if (caregiverTalking) text += " • Sesli iletişim";
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(1001, notification(text));
    }

    @Override public void onDestroy() {
        if (ServiceRestartReceiver.isTracked(this)) ServiceRestartReceiver.schedule(this, 5_000L);
        handler.removeCallbacksAndMessages(null);
        if (lm != null) try { lm.removeUpdates(this); } catch (Exception ignored) {}
        if (camera != null) camera.stop();
        if (micSender != null) micSender.stop();
        if (caregiverAudio != null) caregiverAudio.stop();
        if (base != null) {
            base.child("status/online").setValue(false);
            if (cameraListener != null) base.child("commands/cameraEnabled").removeEventListener(cameraListener);
            if (lensListener != null) base.child("commands/lens").removeEventListener(lensListener);
            if (audioListener != null) base.child("commands/audioEnabled").removeEventListener(audioListener);
            if (caregiverTalkingListener != null) base.child("commands/caregiverTalking").removeEventListener(caregiverTalkingListener);
        }
        super.onDestroy();
    }
}
