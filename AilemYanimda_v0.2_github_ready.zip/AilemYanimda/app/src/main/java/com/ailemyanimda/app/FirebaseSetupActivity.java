package com.ailemyanimda.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class FirebaseSetupActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout r = Ui.root(this);
        r.addView(Ui.title(this,"Ailem Yanımda"));
        r.addView(Ui.text(this,"Ücretsiz bağlantı için Firebase bilgilerini bir kez gir. İki telefonda da aynı bilgileri kullan.",17));
        EditText project = field("Project ID", false);
        EditText appId = field("App ID (ör: 1:123...:android:...)", false);
        EditText api = field("Web API Key", true);
        EditText db = field("Realtime Database URL", false);
        r.addView(project); r.addView(appId); r.addView(api); r.addView(db);
        android.widget.Button save = Ui.button(this,"Kaydet ve devam et",0xff17365d);
        save.setOnClickListener(v -> {
            if (project.getText().toString().trim().isEmpty() || appId.getText().toString().trim().isEmpty()
                    || api.getText().toString().trim().isEmpty() || db.getText().toString().trim().isEmpty()) {
                Toast.makeText(this,"Dört alanı da doldur.",Toast.LENGTH_SHORT).show(); return;
            }
            AppPrefs.put(this,"fb_project_id",project.getText().toString().trim());
            AppPrefs.put(this,"fb_app_id",appId.getText().toString().trim());
            AppPrefs.put(this,"fb_api_key",api.getText().toString().trim());
            AppPrefs.put(this,"fb_db_url",db.getText().toString().trim());
            startActivity(new Intent(this,RoleActivity.class)); finish();
        });
        r.addView(save);
        ScrollView s = new ScrollView(this); s.addView(r); setContentView(s);
    }
    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(true);
        e.setPadding(Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,12));
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        return e;
    }
}
