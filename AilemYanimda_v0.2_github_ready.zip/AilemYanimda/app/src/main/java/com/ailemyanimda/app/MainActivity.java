package com.ailemyanimda.app;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Class<?> next;
        if (AppPrefs.role(this).isEmpty()) next = RoleActivity.class;
        else if ("tracked".equals(AppPrefs.role(this))) next = TrackedActivity.class;
        else next = CaregiverActivity.class;
        startActivity(new Intent(this, next));
        finish();
    }
}
