package com.ailemyanimda.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CreateFamilyActivity extends AppCompatActivity {
    private final SecureRandom random = new SecureRandom();
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout r=Ui.root(this); r.addView(Ui.title(this,"Telefonları eşleştir"));
        TextView info=Ui.text(this,"Bağlantı hazırlanıyor…",18); info.setGravity(Gravity.CENTER); r.addView(info); setContentView(r);
        FirebaseAuth auth=FirebaseProvider.auth(this);
        Runnable go=()->create(info,r,auth.getCurrentUser().getUid());
        if(auth.getCurrentUser()!=null) go.run();
        else auth.signInAnonymously().addOnSuccessListener(x->go.run()).addOnFailureListener(e->error(e.getMessage()));
    }
    private void create(TextView info, LinearLayout r, String uid) {
        String secret=UUID.randomUUID().toString().replace("-","");
        String code=String.format(java.util.Locale.US,"%08d", random.nextInt(100_000_000));
        long expires=System.currentTimeMillis()+10*60*1000L;
        Map<String,Object> m=new HashMap<>(); m.put("secret",secret); m.put("ownerUid",uid); m.put("expiresAt",expires);
        DatabaseReference ref=FirebaseProvider.db(this).getReference("pairCodes").child(code);
        ref.setValue(m).addOnSuccessListener(v->{
            AppPrefs.put(this,"role","caregiver"); AppPrefs.put(this,"family_secret",secret);
            info.setText("Annenizin telefonuna bu kodu girin:\n\n"+code+"\n\nKod 10 dakika geçerlidir.");
            android.widget.Button b=Ui.button(this,"Kontrol paneline geç",0xff1769d2);
            b.setOnClickListener(x->{ startActivity(new Intent(this,CaregiverActivity.class)); finishAffinity(); }); r.addView(b);
        }).addOnFailureListener(e->error(e.getMessage()));
    }
    private void error(String s){ Toast.makeText(this,"Bağlantı hatası: "+s,Toast.LENGTH_LONG).show(); }
}
