package com.ailemyanimda.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon acilinca/eslestirme uygulamasi guncellenince takip servisini geri getirir. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!ServiceRestartReceiver.isTracked(context)) return;

        String action = intent == null ? "" : String.valueOf(intent.getAction());
        boolean supported = Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_USER_UNLOCKED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)
                || "com.htc.intent.action.QUICKBOOT_POWERON".equals(action);
        if (!supported) return;

        // Hemen dene, sonra boot sirasindaki gecici kisitlamalara karsi tekrar dene.
        ServiceRestartReceiver.startTracking(context);
        ServiceRestartReceiver.schedule(context, 20_000L);
    }
}
