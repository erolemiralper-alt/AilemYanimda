package com.ailemyanimda.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class RoleActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout r=Ui.root(this); r.addView(Ui.title(this,"Bu telefon kimin?"));
        r.addView(Ui.text(this,"Kurulum sadece ilk seferde yapılır.",17));
        android.widget.Button mine=Ui.button(this,"Benim telefonum (izleme ve kontrol)",0xff1769d2);
        android.widget.Button mom=Ui.button(this,"Annemin telefonu (takip edilen cihaz)",0xff2ead5b);
        mine.setOnClickListener(v->startActivity(new Intent(this,CreateFamilyActivity.class)));
        mom.setOnClickListener(v->startActivity(new Intent(this,PairTrackedActivity.class)));
        r.addView(mine); r.addView(mom); setContentView(r);
    }
}
