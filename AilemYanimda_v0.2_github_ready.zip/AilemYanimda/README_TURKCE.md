# Ailem Yanımda — v0.2.2

Aynı APK iki telefonda kullanılır:

- **Benim telefonum:** canlı konum, pil, çevrimiçi durumu, SOS, konum geçmişi, kamera görüntüsü ve sesli iletişim.
- **Annemin telefonu:** konum/pil gönderir, SOS sunar; kamera veya mikrofon paylaşımı açıldığında görünür foreground bildirimi gösterir.

## v0.2.2 yenilikleri

- Kamera düşük çözünürlükte yaklaşık 4 kare/sn hedefler; bağlantı yavaşsa eski kareleri biriktirmek yerine atar.
- **Annemin sesini dinle** düğmesiyle takip edilen telefonun mikrofonu açılır.
- **Basılı tut ve konuş** düğmesiyle kendi telefonunuzdan annenizin telefonuna ses gönderilir.
- Ses yaklaşık telefon görüşmesi kalitesinde, 8 kHz mono G.711 µ-law olarak küçük parçalar halinde aktarılır.
- Yankıyı azaltmak için konuşurken karşı yöndeki dinleme geçici olarak durdurulur; düğmeyi bırakınca yeniden açılır.
- Haritada yakınlaştırma/kaydırma yapılırken dıştaki uygulama ScrollView'ının hareket etmesi engellenir.
- Haritaya dokunduktan hemen sonra otomatik konum güncellemesi haritayı yeniden yükleyip zoom seviyesini sıfırlamaz.

## Gerekli izinler

Takip edilen telefonda ilk kurulumda **Konum**, **Kamera** ve **Mikrofon** izinleri verilir. Kontrol telefonunda yalnızca karşı tarafa konuşmak istediğinizde mikrofon izni istenir.

Uygulama kamera veya mikrofon kullanımını gizlemez. Takip edilen telefonda paylaşım durumunu gösteren kalıcı bildirim bulunur.

## Firebase

Firebase Authentication > Anonymous etkin olmalıdır. Realtime Database kuralları için `firebase_database_rules.json` dosyasını kullanın. Uygulamanın ilk ekranında iki telefona da aynı Project ID, App ID, Web API Key ve Realtime Database URL girilir.

Paket adı: `com.ailemyanimda.app`

## Veri kullanımı

- Konum: yaklaşık 60 saniyede bir veya 10 metre hareket sonrası.
- Durum/pil: yaklaşık 30 saniyede bir.
- Kamera: yalnızca kontrol ekranında açıkken yaklaşık 4 kare/sn hedefler.
- Ses: yalnızca **dinleme** veya **basılı tut konuş** aktifken gönderilir. 8 kHz mono ses tercih edilerek veri kullanımı ve eski telefon yükü düşük tutulur.

## TCL / Android 10 notu

`minSdk 23` korunmuştur. Eski Android 10 cihazlarda klasik Android View arayüzü ve foreground service kullanılır. Üreticinin pil tasarrufu servisi kapatırsa uygulama için pil optimizasyonunu kapatmak gerekebilir.


## v0.2.3
- Firebase istemci yapılandırması uygulamaya gömüldü. İlk açılışta Project ID / App ID / API Key / Database URL ekranı artık gösterilmez.
- Kullanıcı akışı rol seçimi ve 8 haneli eşleştirme koduyla devam eder.
- v0.2.2'deki daha akıcı kamera, sesli iletişim ve harita dokunma düzeltmeleri korunur.
