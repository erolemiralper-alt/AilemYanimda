# Ailem Yanımda — v0.1

Bu proje aynı APK'yı iki telefonda kullanır:

- **Benim telefonum:** konum, pil, çevrimiçi durumu, SOS, konum geçmişi ve kamera görüntüsünü gösterir.
- **Annemin telefonu:** konumu ve pil durumunu gönderir, büyük SOS düğmesi sunar. Kamera paylaşımı açılırsa ekranda/bildirim alanında bunun çalıştığı görünür.

## Neden Firebase gerekiyor?
İki telefon farklı Wi‑Fi/mobil ağlarda olduğunda aralarında internet üzerinden güvenli bir aktarım noktası gerekir. Bu proje Firebase Authentication + Realtime Database kullanır. Küçük aile kullanımı için Spark ücretsiz kotası yeterli olacak şekilde tasarlanmıştır.

## Firebase'i bir kez hazırlama
1. Firebase Console'da ücretsiz bir proje oluştur.
2. Authentication > Sign-in method bölümünde **Anonymous** oturum açmayı etkinleştir.
3. Realtime Database oluştur.
4. `firebase_database_rules.json` dosyasındaki kuralları Realtime Database > Rules bölümüne yapıştır ve yayımla.
5. Firebase proje ayarlarından bir Android uygulaması ekle. Paket adı: `com.ailemyanimda.app`
6. Uygulamanın ilk ekranına şu dört değeri iki telefonda da aynı şekilde gir:
   - Project ID
   - App ID
   - Web API Key
   - Realtime Database URL

## Kullanım
1. Kendi telefonunda **Benim telefonum** seç.
2. Ekranda çıkan 8 haneli kodu annenin telefonundaki **Annemin telefonu** ekranına gir.
3. Annenin telefonunda kamera ve konum izinlerini bir kez ver ve **Takibi başlat** de.
4. Kendi telefonunda kontrol panelinden konumu ve pil durumunu görürsün.
5. **Kamerayı aç** dediğinde annenin cihazında görünür bildirimle kamera paylaşımı başlar. Bu sürüm yaklaşık 5 saniyede bir düşük çözünürlüklü kare yollar; tam video değildir.

## Pil ve internet
- Konum: yaklaşık 60 saniyede bir veya 10 metre hareket sonrası.
- Durum/pil: yaklaşık 30 saniyede bir.
- Kamera: yalnızca kontrol ekranında açıkken yaklaşık 5 saniyede bir kare.
- Kamera ekranından çıkınca uzaktan kamera komutu otomatik kapatılır.

## TCL 5002H / Android 10 notu
Bu uygulama `minSdk 23` olarak hazırlanmıştır ve Android 10 cihazları hedefleyen klasik Android View arayüzü kullanır. Takip servisi kalıcı bildirimle foreground service olarak çalışır. TCL'nin pil tasarrufu uygulamayı kapatırsa uygulama için pil optimizasyonunu kapatmak gerekebilir.

## Güvenlik
Eşleştirme kodu 10 dakika geçerlidir. Asıl aile anahtarı tahmin edilmesi pratikte mümkün olmayan rastgele 128 bitlik bir değerdir. Uygulama gizlenmez ve kamera/konum paylaşım durumu kullanıcıdan saklanmaz.

## Android Studio olmadan APK derleme (GitHub Actions)

Bu projede `.github/workflows/build-apk.yml` hazırdır.

1. GitHub hesabında boş bir repository oluşturun (ör. `AilemYanimda`).
2. Bu projenin tüm dosyalarını repository'ye yükleyin.
3. GitHub'da **Actions > Build Android APK** bölümüne girin.
4. **Run workflow** düğmesine basın. Ayrıca main/master dalına her yüklemede otomatik derleme başlar.
5. İşlem başarılı olunca workflow sayfasının **Artifacts** bölümünden `AilemYanimda-debug-apk` dosyasını indirin.
6. ZIP'in içindeki `app-debug.apk` dosyasını iki telefona da kurabilirsiniz.

> Not: APK'nın çalışabilmesi için ilk açılışta uygulamadaki Firebase alanlarının doldurulması ve Firebase Authentication'da Anonymous giriş ile Realtime Database'in etkinleştirilmesi gerekir.
